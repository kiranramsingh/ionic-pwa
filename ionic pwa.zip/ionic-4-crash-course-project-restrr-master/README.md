# Ionic 4 Tutorial Course Project

This is the project based on the following crash course:
[Ionic 4 Crash Course for Beginners - Build an App](https://youtu.be/qTdwUpQRptc)

## More Awesome Content

Do me a big ol' favor and check out these awesome links. I release new video tutorials on full stack development Monday-Thursday @ 10:30 AM ET!

* Subscribe to the [DesignCourse YouTube Channel](http://youtube.com/designcourse)
* Check out the associated website [Coursetro Full Stack Development Training](https://coursetro.com)
* Chat with me and others on Discord: [DesignCourse Discord Server](https://discord.gg/a27CKAF)
* [Twitter](https://twitter.com/designcoursecom)
* [Facebook](https://facebook.com/coursetro)

Enjoy!